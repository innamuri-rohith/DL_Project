import { createInsertSchema } from "drizzle-zod";
import { integer, numeric, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const riskZonesTable = pgTable("risk_zones", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  region: text("region").notNull(),
  risk: numeric("risk", { precision: 5, scale: 2 }).notNull(),
  riskType: text("risk_type").notNull(),
  change: numeric("change", { precision: 5, scale: 2 }).notNull(),
  area: numeric("area", { precision: 10, scale: 2 }).notNull(),
  coordinates: numeric("coordinates", { precision: 12, scale: 6 }).array().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const observationsTable = pgTable("observations", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  subject: text("subject").notNull(),
  location: text("location").notNull(),
  confidence: numeric("confidence", { precision: 5, scale: 2 }).notNull(),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
  source: text("source").notNull(),
  status: text("status").notNull().default("review"),
});

export const alertsTable = pgTable("forest_alerts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull(),
  location: text("location").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  signal: text("signal").notNull(),
});

export const activityTable = pgTable("forest_activity", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  detail: text("detail").notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
  tone: text("tone").notNull(),
});

export const insertObservationSchema = createInsertSchema(observationsTable).omit({ id: true, recordedAt: true });
export type InsertObservation = z.infer<typeof insertObservationSchema>;
export type RiskZone = typeof riskZonesTable.$inferSelect;
export type Observation = typeof observationsTable.$inferSelect;
export type ForestAlert = typeof alertsTable.$inferSelect;
export type ActivityItem = typeof activityTable.$inferSelect;
