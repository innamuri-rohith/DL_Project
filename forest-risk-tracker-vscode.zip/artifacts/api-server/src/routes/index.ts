import { Router, type IRouter } from "express";
import healthRouter from "./health";
import forestRouter from "./forest";

const router: IRouter = Router();

router.use(healthRouter);
router.use(forestRouter);

export default router;
