import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { db, activityTable, alertsTable, observationsTable, riskZonesTable } from "@workspace/db";
import {
  CreateObservationBody,
  GetAlertsQueryParams,
  GetObservationsQueryParams,
  UpdateAlertBody,
  UpdateAlertParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

const seedZones = [
  { name: "Silent Valley North", region: "Nilgiri Biosphere", risk: "91.00", riskType: "wildfire", change: "14.20", area: "1840.00", coordinates: ["11.295", "76.420"] },
  { name: "Kanha Buffer East", region: "Madhya Pradesh", risk: "78.00", riskType: "deforestation", change: "8.60", area: "920.00", coordinates: ["22.334", "80.742"] },
  { name: "Kaziranga Wetlands", region: "Assam Floodplain", risk: "64.00", riskType: "ecological", change: "-2.40", area: "640.00", coordinates: ["26.577", "93.171"] },
  { name: "Bandipur South Ridge", region: "Western Ghats", risk: "49.00", riskType: "wildfire", change: "3.10", area: "1180.00", coordinates: ["11.650", "76.630"] },
];

const seedObservations = [
  { type: "wildlife", subject: "Asian elephant herd", location: "Silent Valley North", confidence: "96.00", source: "Sentinel-2 + ranger report", status: "verified" },
  { type: "wildlife", subject: "Tiger corridor crossing", location: "Kanha Buffer East", confidence: "88.00", source: "Camera trap sync", status: "verified" },
  { type: "vegetation", subject: "Canopy stress cluster", location: "Bandipur South Ridge", confidence: "79.00", source: "NDVI change model", status: "review" },
  { type: "vegetation", subject: "Wetland regeneration", location: "Kaziranga Wetlands", confidence: "91.00", source: "Sentinel-2 time series", status: "emerging" },
];

const seedAlerts = [
  { title: "Rapid heat signature detected", description: "A cluster of thermal anomalies was detected along the northern firebreak.", severity: "critical", location: "Silent Valley North", status: "open", signal: "VIIRS thermal + wind" },
  { title: "Canopy loss above threshold", description: "Vegetation index dropped 8.6% in the monitored buffer over the last 14 days.", severity: "high", location: "Kanha Buffer East", status: "open", signal: "NDVI change model" },
  { title: "Wildlife corridor activity", description: "A verified elephant herd signal is moving toward a high-traffic access road.", severity: "medium", location: "Silent Valley North", status: "acknowledged", signal: "Ranger report + satellite" },
  { title: "Seasonal vegetation recovery", description: "Wetland vegetation is recovering above the expected seasonal baseline.", severity: "low", location: "Kaziranga Wetlands", status: "resolved", signal: "NDVI time series" },
];

const seedActivity = [
  { label: "Risk model refreshed", detail: "4 zones recalculated from the latest satellite pass", tone: "blue" },
  { label: "Alert escalated", detail: "Rapid heat signature detected in Silent Valley North", tone: "red" },
  { label: "Wildlife signal verified", detail: "Asian elephant herd · ranger report matched", tone: "green" },
  { label: "Field review requested", detail: "Canopy stress cluster needs local confirmation", tone: "amber" },
];

let seedPromise: Promise<void> | null = null;

async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = (async () => {
      const [zoneCount, observationCount, alertCount, activityCount] = await Promise.all([
        db.select({ id: riskZonesTable.id }).from(riskZonesTable).limit(1),
        db.select({ id: observationsTable.id }).from(observationsTable).limit(1),
        db.select({ id: alertsTable.id }).from(alertsTable).limit(1),
        db.select({ id: activityTable.id }).from(activityTable).limit(1),
      ]);
      if (zoneCount.length === 0) await db.insert(riskZonesTable).values(seedZones);
      if (observationCount.length === 0) await db.insert(observationsTable).values(seedObservations);
      if (alertCount.length === 0) await db.insert(alertsTable).values(seedAlerts);
      if (activityCount.length === 0) await db.insert(activityTable).values(seedActivity);
    })();
  }
  await seedPromise;
}

function iso(value: Date | string) {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function mapZone(zone: typeof riskZonesTable.$inferSelect) {
  return {
    ...zone,
    risk: Number(zone.risk),
    change: Number(zone.change),
    area: Number(zone.area),
    coordinates: zone.coordinates.map(Number),
    updatedAt: iso(zone.updatedAt),
  };
}

function mapObservation(observation: typeof observationsTable.$inferSelect) {
  return { ...observation, confidence: Number(observation.confidence), recordedAt: iso(observation.recordedAt) };
}

function mapAlert(alert: typeof alertsTable.$inferSelect) {
  return { ...alert, createdAt: iso(alert.createdAt) };
}

router.get("/forest/overview", async (req, res) => {
  await ensureSeeded();
  const [zones, alerts, observations] = await Promise.all([
    db.select().from(riskZonesTable),
    db.select().from(alertsTable),
    db.select().from(observationsTable),
  ]);
  const openAlerts = alerts.filter((alert) => alert.status !== "resolved");
  const highRiskZones = zones.filter((zone) => Number(zone.risk) >= 70);
  const wildlifeSignals = observations.filter((observation) => observation.type === "wildlife").length;
  req.log.info({ zones: zones.length, alerts: openAlerts.length }, "Forest overview requested");
  res.json({
    lastUpdated: new Date().toISOString(),
    monitoredArea: zones.reduce((sum, zone) => sum + Number(zone.area), 0),
    highRiskZones: highRiskZones.length,
    activeAlerts: openAlerts.length,
    wildlifeSignals,
    vegetationChange: -4.8,
    trend: [
      { label: "08 Aug", risk: 42, vegetation: 78 },
      { label: "15 Aug", risk: 48, vegetation: 74 },
      { label: "22 Aug", risk: 45, vegetation: 76 },
      { label: "29 Aug", risk: 61, vegetation: 69 },
      { label: "05 Sep", risk: 68, vegetation: 64 },
    ],
  });
});

router.get("/forest/risk-zones", async (_req, res) => {
  await ensureSeeded();
  const zones = await db.select().from(riskZonesTable).orderBy(desc(riskZonesTable.risk));
  res.json(zones.map(mapZone));
});

router.get("/forest/observations", async (req, res) => {
  await ensureSeeded();
  const query = GetObservationsQueryParams.parse(req.query);
  const rows = await db.select().from(observationsTable).orderBy(desc(observationsTable.recordedAt));
  const filtered = query.type === "all" ? rows : rows.filter((row) => row.type === query.type);
  res.json(filtered.slice(0, query.limit).map(mapObservation));
});

router.post("/forest/observations", async (req, res) => {
  await ensureSeeded();
  const input = CreateObservationBody.parse(req.body);
  const [created] = await db.insert(observationsTable).values({
    ...input,
    confidence: String(input.confidence),
    status: input.confidence >= 85 ? "verified" : "review",
  }).returning();
  res.status(201).json(mapObservation(created));
});

router.get("/forest/alerts", async (req, res) => {
  await ensureSeeded();
  const query = GetAlertsQueryParams.parse(req.query);
  const rows = await db.select().from(alertsTable).orderBy(desc(alertsTable.createdAt));
  const filtered = query.status === "all" ? rows : rows.filter((row) => row.status === query.status);
  res.json(filtered.map(mapAlert));
});

router.patch("/forest/alerts/:id", async (req, res) => {
  await ensureSeeded();
  const { id } = UpdateAlertParams.parse(req.params);
  const { status } = UpdateAlertBody.parse(req.body);
  const [updated] = await db.update(alertsTable).set({ status }).where(eq(alertsTable.id, id)).returning();
  if (!updated) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }
  req.log.info({ id, status }, "Forest alert updated");
  res.json(mapAlert(updated));
});

router.get("/forest/activity", async (_req, res) => {
  await ensureSeeded();
  const rows = await db.select().from(activityTable).orderBy(desc(activityTable.timestamp));
  res.json(rows.map((item) => ({ ...item, timestamp: iso(item.timestamp) })));
});

export default router;