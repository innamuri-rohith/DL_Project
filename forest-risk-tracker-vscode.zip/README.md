# Forest Risk & Wildlife Tracker

Software-only forest monitoring dashboard for wildfire risk, deforestation signals, wildlife observations, vegetation changes, and forest department response alerts.

## What is included

- React + Vite dashboard
- Express API server
- PostgreSQL database with Drizzle ORM
- Risk zones for wildfire, deforestation, and ecological change
- Wildlife and vegetation observation log
- Forest department alert queue
- Persistent alert status updates
- Seed data for a working first run

## Requirements

- Node.js 20 or newer
- pnpm 9 or newer
- PostgreSQL 14 or newer

## Run in VS Code

Open the project folder in VS Code, then open two integrated terminals.

### 1. Install dependencies

```bash
pnpm install
```

### 2. Configure PostgreSQL

Create a PostgreSQL database and set `DATABASE_URL`.

macOS/Linux:

```bash
export DATABASE_URL="postgresql://postgres:password@localhost:5432/forest_tracker"
```

Windows PowerShell:

```powershell
$env:DATABASE_URL="postgresql://postgres:password@localhost:5432/forest_tracker"
```

Push the database tables:

```bash
pnpm --filter @workspace/db run push
```

### 3. Start the API server

macOS/Linux:

```bash
DATABASE_URL="$DATABASE_URL" PORT=5000 pnpm --filter @workspace/api-server run dev
```

Windows PowerShell:

```powershell
$env:PORT="5000"
pnpm --filter @workspace/api-server run dev
```

The API runs at `http://localhost:5000`.

### 4. Start the web app

macOS/Linux:

```bash
VSCODE_LOCAL=true API_URL=http://localhost:5000 PORT=5173 BASE_PATH=/ pnpm --filter @workspace/forest-risk-tracker run dev
```

Windows PowerShell:

```powershell
$env:VSCODE_LOCAL="true"
$env:API_URL="http://localhost:5000"
$env:PORT="5173"
$env:BASE_PATH="/"
pnpm --filter @workspace/forest-risk-tracker run dev
```

Open `http://localhost:5173` in your browser.

The `VSCODE_LOCAL=true` setting enables the Vite proxy so frontend requests to `/api` reach the API server.

## Useful commands

```bash
# Check all TypeScript packages
pnpm run typecheck

# Build the web app
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/forest-risk-tracker run build

# Regenerate typed API clients after changing the OpenAPI contract
pnpm --filter @workspace/api-spec run codegen
```

## Project structure

```text
artifacts/forest-risk-tracker/   React dashboard
artifacts/api-server/            Express API
lib/api-spec/                    OpenAPI source contract
lib/api-client-react/            Generated React Query client
lib/api-zod/                     Generated request/response validators
lib/db/                          Drizzle schema and database package
```